package CFMIS_SuperAdmin;

public class SetUserRoles extends SetUserRolesBaseTest {
	
	public void LoginSuperAdmin() throws Exception{
		
		browserUsed();
		CredentialsLogin();
		ClickLogin();	
	}

}
