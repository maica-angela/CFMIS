package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import common.BasePage;

public class PageObject extends BasePage {
	
	public PageObject (WebDriver driver) {
		super(driver);
		//this.driver = driver;
	}
}